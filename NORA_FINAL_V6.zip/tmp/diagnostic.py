import os
import psutil
import json
from supabase import create_client, Client
from dotenv import load_dotenv
import google.generativeai as genai

# Carga de entorno
load_dotenv(dotenv_path=r"D:\AGENTE_IA\.env")

def check_ram():
    process = psutil.Process(os.getpid())
    mem_mb = process.memory_info().rss / (1024 * 1024)
    total_mem_gb = psutil.virtual_memory().total / (1024**3)
    return mem_mb, total_mem_gb

def check_connections():
    results = {}
    
    # Supabase
    url = os.environ.get("SUPABASE_URL")
    key = os.environ.get("SUPABASE_KEY")
    try:
        if not url or "tu-proyecto" in url:
            results["Supabase"] = "Error: URL de placeholder detectada."
        else:
            supabase = create_client(url, key)
            # Intento de lectura mínima en ia_mensajes
            res = supabase.table("ia_mensajes").select("id").limit(1).execute()
            results["Supabase"] = "Conexión Exitosa (Lectura OK)"
    except Exception as e:
        results["Supabase"] = f"Error: {e}"
        
    # Gemini
    gemini_key = os.environ.get("GEMINI_API_KEY")
    try:
        if not gemini_key or "AIzaSy" not in gemini_key:
             results["Gemini"] = "Error: Clave de Gemini inválida o faltante."
        else:
            genai.configure(api_key=gemini_key)
            model = genai.GenerativeModel('gemini-1.5-flash')
            # Prueba de generación mínima
            response = model.generate_content("Ping")
            results["Gemini"] = "Conexión Exitosa (Generación OK)"
    except Exception as e:
        results["Gemini"] = f"Error: {e}"
        
    return results

def check_files():
    required = [
        r"D:\AGENTE_IA\.env",
        r"D:\AGENTE_IA\Knowledge\pedagogia_contable.json",
        r"D:\AGENTE_IA\Knowledge\persona.txt",
        r"D:\AGENTE_IA\Scripts\ia_brain.py",
        r"D:\AGENTE_IA\Scripts\ia_responder.py",
        r"D:\AGENTE_IA\Scripts\ia_summary_generator.py"
    ]
    missing = [f for f in required if not os.path.exists(f)]
    return missing

if __name__ == "__main__":
    mem_used, mem_total = check_ram()
    conns = check_connections()
    missing_files = check_files()
    
    report = {
        "ram_usage_mb": mem_used,
        "total_system_ram_gb": mem_total,
        "connections": conns,
        "missing_files": missing_files
    }
    print(json.dumps(report, indent=2))
