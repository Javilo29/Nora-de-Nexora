import os
import threading
from flask import Flask
from Guiones import ia_telegram_bot

# --- SERVIDOR KEEP-ALIVE PARA REPLIT ---
# Esto evita que Replit apague a Nora cuando cierres la laptop.
app = Flask(__name__)

@app.route('/')
def home():
    return "🧠 Nora de Nexora v6.0: Operativa y Vigilante 24/7."

def run_flask():
    # El puerto 8080 es el estándar de Replit para servicios web
    app.run(host='0.0.0.0', port=8080)

# --- INICIO DEL SISTEMA ---
if __name__ == "__main__":
    print("🚀 Iniciando Nora de Nexora v6.0 en Modo Multicanal...")
    
    # 1. Lanzamos el latido de corazón en un hilo paralelo
    t = threading.Thread(target=run_flask)
    t.daemon = True
    t.start()
    
    # 2. Lanzamos tu socia de Telegram (El proceso principal)
    try:
        ia_telegram_bot.run_bot()
    except Exception as e:
        print(f"❌ Error al arrancar el bot: {e}")