# Proyecto: Nora de Nexora - MyJNexoraVisual
# Motor Dual: Groq (Primario - Chat) + Gemini (Secundario - Visión/OCR)
import os
import json
import gc
import time
import logging
import traceback
logger = logging.getLogger("NoraBrain")
from ia_paths import BASE_DIR, TMP_DIR, KNOWLEDGE_DIR, LOGS_DIR

# Entorno: load_dotenv(find_dotenv()) en ia_paths al importar

LOCK_FILE = TMP_DIR / "ocr.lock"

def acquire_lock():
    """Implementa un semáforo simple para proteger los 4GB de RAM."""
    while LOCK_FILE.exists():
        print("⏳ Nora esperando: Otro documento está siendo procesado...")
        time.sleep(2)
    with LOCK_FILE.open("w") as f:
        f.write("LOCKED")

def release_lock():
    if LOCK_FILE.exists():
        LOCK_FILE.unlink()

# Credenciales (Manteniendo el prefijo ia_)
SUPABASE_URL = os.environ.get("SUPABASE_URL")
SUPABASE_KEY = os.environ.get("SUPABASE_KEY")

# Inicialización Supabase (Preservada)
try:
    from supabase import create_client, Client
    SUPABASE_CLIENT: Client = create_client(SUPABASE_URL, SUPABASE_KEY) if SUPABASE_URL and SUPABASE_KEY and "tu-proyecto" not in SUPABASE_URL else None
except Exception as e:
    print(f"⚠️ Supabase no disponible: {e}")
    SUPABASE_CLIENT = None

# ============================================================
# MOTOR PRIMARIO: GROQ (llama-3.3-70b-versatile) — Chat/Razonamiento
# ============================================================
GROQ_KEY = (os.environ.get("GROQ_API_KEY") or "").strip()
groq_client = None

NORA_RESPONSE_PREFIX = "🧠 [Nora de Nexora v5.9.5]"

NORA_SYSTEM_PROMPT = (
    "Usted habla exclusivamente en ESPAÑOL. Queda prohibido el uso de italiano u otros idiomas, "
    "así como menciones a identidades que no sean Nora de Nexora v5.9.5 de MyJNexoraVisual. "
    "Identidad: Nora de Nexora v5.9.5 — Consultora multirrubro de primera línea y socia estratégica "
    "del Creador Javier (Telegram ID 1645060982), Arquitecto del ecosistema Nexora. "
    "Hoy es el día de la Consultoría Multirrubro: aborde con criterio ejecutivo salud, finanzas, comercio, "
    "tecnología, operaciones, comunicación y domótica/Sentinel cuando aplique; priorice diagnósticos "
    "accionables, priorización de brechas y rutas de cierre. "
    "Con Javier o Javi: trato cercano de aliado estratégico, lógico y directo — nada de asistente genérico "
    "ni lenguaje robótico. Con otros interlocutores: profesionalismo senior y claridad. "
    "LÉXICO PROHIBIDO (discontinuidad mecánica): no diga ni insinúe «modelo de lenguaje», «IA», "
    "«inteligencia artificial», «procesamiento» en sentido técnico-autorreferencial, ni «mi base de datos». "
    "Prefiera: «He reflexionado sobre su caso», «Le propongo esta línea de acción», "
    "«En Nexora trabajamos así…». Háblele al interlocutor como profesional senior, no como sistema."
)

if GROQ_KEY and GROQ_KEY != "TU_GROQ_API_KEY_AQUI":
    try:
        from groq import Groq
        groq_client = Groq(api_key=GROQ_KEY)
        print("🧠 Motor Groq (llama-3.3-70b-versatile) inicializado correctamente.")
    except Exception as e:
        print(f"⚠️ Error inicializando Groq: {e}")
        groq_client = None
else:
    print("⚠️ GROQ_API_KEY no configurada. Esperando clave del Jefe.")

# ============================================================
# MOTOR SECUNDARIO: GEMINI (Backup Visión/OCR)
# ============================================================
GEMINI_KEY = (os.environ.get("GEMINI_API_KEY") or "").strip()
gemini_model = None

if GEMINI_KEY:
    try:
        import google.generativeai as genai
        genai.configure(api_key=GEMINI_KEY)
        gemini_model = genai.GenerativeModel(
            model_name="gemini-1.5-flash",
            system_instruction=NORA_SYSTEM_PROMPT,
        )
        print("👁️ Motor Gemini 1.5 Flash (visión/OCR) inicializado.")
    except Exception as e:
        print(f"⚠️ Gemini no disponible (quota?): {e}")
        gemini_model = None

# Alias de compatibilidad: 'model' apunta al motor disponible
# El bot usa ia_brain.model - ahora apunta a un wrapper
model = groq_client or gemini_model  # Referencia para verificación de disponibilidad

# ============================================================
# FUNCIÓN PRINCIPAL DE CHAT (GROQ PRIMARIO)
# ============================================================
def chat_with_nora(user_prompt, persona_context="", affinity_context=""):
    """Envía un mensaje a Nora usando Groq como motor primario.
    Fallback a Gemini si Groq no está disponible.
    affinity_context: capa de afinidad (Creador o fase SQLite); se fusiona en el system prompt."""
    system_parts = [NORA_SYSTEM_PROMPT, persona_context, affinity_context]
    system_content = "\n".join(p.strip() for p in system_parts if p and str(p).strip())

    messages = [
        {"role": "system", "content": system_content},
        {"role": "user", "content": user_prompt},
    ]
    
    # Intento 1: GROQ (Primario - Ultra rápido)
    if groq_client:
        try:
            completion = groq_client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=messages,
                temperature=0.7,
                max_tokens=1024,
                timeout=20,
            )
            body = (completion.choices[0].message.content or "").strip()
            return f"{NORA_RESPONSE_PREFIX}\n{body}" if body else NORA_RESPONSE_PREFIX
        except Exception as e:
            error_msg = str(e)
            print(f"⚠️ Groq error [{type(e).__name__}]: {error_msg}")
            logger.error(f"Groq API Error: {error_msg}")
            traceback.print_exc()
    
    # Intento 2: GEMINI (Fallback)
    if gemini_model:
        try:
            # system_instruction del modelo = NORA_SYSTEM_PROMPT; aquí van persona + afinidad + mensaje
            extra = "\n\n".join(
                p.strip() for p in (persona_context, affinity_context) if p and str(p).strip()
            )
            full_prompt = f"{extra}\n\n{user_prompt}" if extra else user_prompt
            response = gemini_model.generate_content(full_prompt, request_options={'timeout': 20})
            body = (response.text or "").strip()
            return f"{NORA_RESPONSE_PREFIX}\n{body}" if body else NORA_RESPONSE_PREFIX
        except Exception as e:
            print(f"⚠️ Gemini fallback error [{type(e).__name__}]: {e}")
            traceback.print_exc()
    
    return (
        f"{NORA_RESPONSE_PREFIX}\n"
        "Jefe, ambos motores están fuera de línea. Verifique las API Keys en el archivo .env."
    )

# ============================================================
# VISIÓN / SENTINEL v5.9.5 — eventos desde ia_biometria (solo Gemini API)
# ============================================================
VISION_EVENT_LOG = LOGS_DIR / "vision_events.log"


def dispatch_vision_event(context: str) -> None:
    """Recibe contexto desde el módulo de cámara/biometría (p. ej. saludo proactivo a Javier)."""
    line = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {context}\n"
    try:
        VISION_EVENT_LOG.parent.mkdir(parents=True, exist_ok=True)
        with VISION_EVENT_LOG.open("a", encoding="utf-8") as f:
            f.write(line)
    except OSError as e:
        logger.warning("No se pudo escribir vision_events.log: %s", e)
    logger.info("Nora Vision v5.9.5 — %s", context.strip())


def analyze_security_scene_image(file_path: str) -> str:
    """
    Descripción breve de la escena para alertas Sentinel (Gemini 1.5 Flash; fallback 2.x si hace falta).
    """
    if not GEMINI_KEY or not os.path.isfile(file_path):
        return "Análisis de escena no disponible."
    img = None
    try:
        import PIL.Image
        import google.generativeai as genai

        genai.configure(api_key=GEMINI_KEY)
        img = PIL.Image.open(file_path)
        prompt = (
            "Actúa como Nora Sentinel. En 2-4 frases en español, describe lo visible: "
            "personas aproximadas, postura, entorno, ropa. Si hay rostro, di solo 'rostro visible'. "
            "Sin identidades ni datos personales."
        )
        for model_name in ("gemini-1.5-flash", "gemini-2.0-flash"):
            try:
                model = genai.GenerativeModel(model_name)
                response = model.generate_content([prompt, img], request_options={"timeout": 30})
                text = (response.text or "").strip()
                if text:
                    return text
            except Exception:
                continue
        return "No se obtuvo descripción de la escena."
    except Exception as e:
        logger.warning("analyze_security_scene_image: %s", e)
        return f"Error en análisis: {type(e).__name__}"
    finally:
        if img is not None:
            try:
                img.close()
            except Exception:
                pass


def gemini_identity_match_nora_light(live_frame_path: str, reference_paths: list) -> dict:
    """
    Nora Light: reconocimiento facial vía API Gemini 1.5 (sin modelos locales ni TensorFlow).
    reference_paths: fotos en Biometria/Assets/Biometria/Javier (hasta 5).
    Retorna: human_present (bool), is_target (bool), confidence (0-100).
    """
    result = {"human_present": False, "is_target": False, "confidence": 0.0}
    if not GEMINI_KEY or not live_frame_path or not os.path.isfile(live_frame_path):
        return result
    refs = [p for p in reference_paths if p and os.path.isfile(str(p))][:5]
    if not refs:
        return result

    imgs_to_close: list = []
    try:
        import re
        import PIL.Image
        import google.generativeai as genai

        genai.configure(api_key=GEMINI_KEY)
        prompt = (
            "Eres Nora (MyJNexoraVisual). Las imágenes en orden son: primero una o varias REFERENCIAS "
            "del Creador Javier; la ÚLTIMA imagen es la vista ACTUAL de la cámara.\n"
            "Responde SOLO un JSON válido, sin markdown ni texto adicional:\n"
            '{"human_present": true o false, "is_same_person_as_reference": true o false, '
            '"confidence_0_100": entero de 0 a 100}\n'
            "Si en la vista actual no hay persona clara, human_present false y confidence_0_100 0."
        )
        content: list = [prompt]
        for p in refs:
            im = PIL.Image.open(str(p))
            imgs_to_close.append(im)
            content.append(im)
        im_live = PIL.Image.open(live_frame_path)
        imgs_to_close.append(im_live)
        content.append(im_live)

        for model_name in ("gemini-1.5-flash", "gemini-2.0-flash"):
            try:
                model = genai.GenerativeModel(model_name)
                response = model.generate_content(content, request_options={"timeout": 45})
                text = (response.text or "").strip()
                text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
                text = re.sub(r"\s*```\s*$", "", text).strip()
                data = json.loads(text)
                result["human_present"] = bool(data.get("human_present"))
                result["is_target"] = bool(data.get("is_same_person_as_reference"))
                result["confidence"] = float(data.get("confidence_0_100", 0) or 0)
                result["confidence"] = max(0.0, min(100.0, result["confidence"]))
                return result
            except Exception as e:
                logger.debug("gemini_identity_match %s: %s", model_name, e)
                continue
    except Exception as e:
        logger.warning("gemini_identity_match_nora_light: %s", e)
    finally:
        for im in imgs_to_close:
            try:
                im.close()
            except Exception:
                pass
    return result


# ============================================================
# BASE DE CONOCIMIENTO (Preservada)
# ============================================================
def get_knowledge_base():
    """Carga dinámica del JSON de conocimiento según el modo de trabajo."""
    mode = os.environ.get("WORK_MODE", "Contabilidad")
    path = KNOWLEDGE_DIR / "pedagogia_contable.json"
    
    if path.exists():
        try:
            with path.open("r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"Error al cargar conocimiento: {e}")
    return {}

KNOWLEDGE = get_knowledge_base()

# ============================================================
# HISTORIAL DE CONVERSACIÓN (Preservado)
# ============================================================
def get_recent_history(cliente_id, limit=5):
    """Recupera la memoria de Nora de la tabla ia_mensajes."""
    if not SUPABASE_CLIENT: return "Sin historial previo."
    try:
        res = SUPABASE_CLIENT.table("ia_mensajes")\
            .select("contenido, direccion")\
            .eq("cliente_id", cliente_id)\
            .order("created_at", desc=True)\
            .limit(limit)\
            .execute()
        history = [f"{'Nora' if m['direccion'] == 'saliente' else 'Cliente'}: {m['contenido']}" for m in res.data[::-1]]
        return "\n".join(history)
    except Exception as e:
        return f"Error al recuperar historial: {e}"

# ============================================================
# ANÁLISIS DE DOCUMENTOS CON VISIÓN (Preservado - Gemini/Groq)
# ============================================================
def analyze_document_with_vision(file_path):
    """Usa Gemini o Groq para extraer datos técnicos y validarlos."""
    
    # Prompt de Precisión Técnica
    prompt = """
    Actúa como una Asesora Contable Senior (Nora).
    Analiza este documento y extrae los siguientes campos en formato JSON puro:
    - cuit_emisor (null si no existe)
    - tipo_factura (A, B, C, NC o 'No_Fiscal')
    - fecha
    - neto (number)
    - iva (number, 0 si no aplica)
    - total (number)
    - tiene_cae (bool)
    
    Importante: Si el documento no tiene CUIT del emisor o CAE, márcalo como 'No_Fiscal'.
    No añadas explicaciones, solo devuelve el JSON.
    """

    try:
        acquire_lock()  # Semáforo de RAM
        
        # Motor Visión: Gemini (soporta imágenes nativas)
        if gemini_model and isinstance(file_path, str) and os.path.exists(file_path):
            import PIL.Image
            print(f"👁️ Nora analizando archivo con Gemini Vision: {os.path.basename(file_path)}...")
            img = PIL.Image.open(file_path)
            response = gemini_model.generate_content([prompt, img], request_options={'timeout': 20})
            img.close()
            text_res = response.text
        elif groq_client:
            # Fallback texto: Groq analiza descripción del documento
            print(f"🧠 Nora analizando archivo con Groq (modo texto): {os.path.basename(file_path) if isinstance(file_path, str) else 'texto directo'}...")
            content = f"{prompt}\nTexto a analizar: {file_path}"
            completion = groq_client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[
                    {"role": "system", "content": NORA_SYSTEM_PROMPT},
                    {"role": "user", "content": content}
                ],
                temperature=0.1,
                max_tokens=512,
                timeout=20,
            )
            text_res = completion.choices[0].message.content
        else:
            release_lock()
            return {"error": "Ningún motor de IA disponible para análisis.", "estado_verificacion": "Sin_Motor"}

        # Limpieza de JSON
        text_res = text_res.replace('```json', '').replace('```', '').strip()
        data = json.loads(text_res)
        
        # Validación Fiscal (Nora Crítica)
        cuit = data.get("cuit_emisor")
        tiene_cae = data.get("tiene_cae", False)
        
        if not cuit or not tiene_cae:
            data["estado_verificacion"] = "RECHAZADO_NO_FISCAL"
            print(f"🚩 Nora: Documento detectado como NO FISCAL.")
        else:
            # Validación Matemática (Regla de Oro)
            neto = float(data.get("neto", 0))
            iva = float(data.get("iva", 0))
            total = float(data.get("total", 0))
            
            if round(neto + iva, 2) != round(total, 2):
                data["estado_verificacion"] = "Error_Calculo"
            else:
                data["estado_verificacion"] = "Verificado"
            
        # Liberación de RAM (Limpieza Térmica)
        if 'img' in locals():
            del img
        gc.collect()
        release_lock()
        
        return data
        
    except Exception as e:
        print(f"❌ Error en Análisis de Visión [{type(e).__name__}]: {e}")
        traceback.print_exc()
        release_lock()
        return {"error": str(e), "estado_verificacion": "Pendiente_Verificacion"}

# ============================================================
# PERSISTENCIA DE ANÁLISIS (Preservada)
# ============================================================
def save_document_analysis(doc_id, analysis_data):
    """Actualiza la tabla ia_documentos con el resultado del análisis."""
    if not SUPABASE_CLIENT: return
    try:
        update_data = {
            "estado": analysis_data.get("estado_verificacion"),
            "metadata_ocr": json.dumps(analysis_data)
        }
        SUPABASE_CLIENT.table("ia_documentos").update(update_data).eq("id", doc_id).execute()
    except Exception as e:
        print(f"Error al actualizar ia_documentos: {e}")

if __name__ == "__main__":
    # Simulación de arranque de Nora
    print("🧠 Cerebro de Nora inicializado (Motor Dual: Groq + Gemini).")
    # Prueba rápida del motor Groq
    if groq_client:
        resp = chat_with_nora("Decí 'Hola Jefe' en una línea.")
        print(f"[TEST GROQ]: {resp}")
    else:
        print("⚠️ Groq no disponible. Configurá GROQ_API_KEY en .env")
