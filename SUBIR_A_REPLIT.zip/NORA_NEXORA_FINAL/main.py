# -*- coding: utf-8 -*-
"""
Nexora / Nora v5.9.5 — arranque local o Replit.

Uso:
  python main.py              → bot Telegram + keep-alive HTTP :8080 (Replit 24/7)
  python main.py dashboard    → panel Streamlit
  python main.py bot          → idem que sin argumentos

Keep-alive: GET / → texto plano «Nora Online 24/7» (puerto KEEPALIVE_PORT o 8080).
Replit: Secrets + Run `python main.py`. Opcional NEXORA_MODE=dashboard.
"""
from __future__ import annotations

import os
import subprocess
import sys
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parent
GUIONES = ROOT / "Guiones"
DASHBOARD = GUIONES / "ia_dashboard.py"
BOT = GUIONES / "ia_telegram_bot.py"


def _start_keepalive_http() -> None:
    """Servidor Flask mínimo en hilo daemon para que Replit mantenga el Repl activo."""
    try:
        from flask import Flask
    except ImportError:
        print(
            "⚠️ Flask no instalado: pip install flask — el keep-alive HTTP no arrancará.",
            file=sys.stderr,
            flush=True,
        )
        return

    app = Flask(__name__)

    @app.route("/")
    def _root():
        return "Nora Online 24/7", 200, {"Content-Type": "text/plain; charset=utf-8"}

    port = int(os.environ.get("KEEPALIVE_PORT", os.environ.get("PORT", "8080")))

    def _run() -> None:
        app.run(host="0.0.0.0", port=port, use_reloader=False, threaded=True)

    threading.Thread(target=_run, name="NoraKeepAlive", daemon=True).start()
    print(f"🌐 Keep-alive HTTP en 0.0.0.0:{port} (Nora Online 24/7)", flush=True)


def _run_dashboard() -> int:
    port = os.environ.get("PORT", "8501")
    cmd = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        str(DASHBOARD),
        "--server.address",
        "0.0.0.0",
        "--server.port",
        str(port),
        "--browser.gatherUsageStats",
        "false",
    ]
    return subprocess.call(cmd, cwd=str(ROOT))


def _run_bot() -> int:
    _start_keepalive_http()
    return subprocess.call([sys.executable, str(BOT)], cwd=str(GUIONES))


def main() -> int:
    mode = (
        sys.argv[1].lower()
        if len(sys.argv) > 1
        else os.environ.get("NEXORA_MODE", "bot").lower()
    )
    if mode in ("dashboard", "streamlit", "ui", "panel"):
        return _run_dashboard()
    if mode in ("bot", "telegram", "tg"):
        return _run_bot()
    print(
        "Nexora — modos: bot | dashboard\n"
        "  python main.py              → Telegram + keep-alive :8080\n"
        "  python main.py dashboard    → Streamlit (puerto PORT o 8501)\n",
        file=sys.stderr,
    )
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
