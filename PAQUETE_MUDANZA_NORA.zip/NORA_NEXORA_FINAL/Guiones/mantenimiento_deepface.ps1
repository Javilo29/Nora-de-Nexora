# Nora — Liberar espacio en C: por modelos DeepFace (.deepface/weights)
# Ejecutar en PowerShell:  Set-ExecutionPolicy -Scope CurrentUser RemoteSigned -Force
#                          .\mantenimiento_deepface.ps1
# Opciones: -EliminarSinCopia  (borra C:\Users\<usuario>\.deepface sin mover; recupera ~4GB+)

param(
    [switch] $EliminarSinCopia
)

$ErrorActionPreference = "Stop"
$srcRoot = Join-Path $env:USERPROFILE ".deepface"
$dstParent = "D:\Biblioteca\Escritorio\NORA_NEXORA_FINAL\data"
$dstDeepface = Join-Path $dstParent ".deepface"

Write-Host "Origen: $srcRoot"
Write-Host "Destino padre (DEEPFACE_HOME): $dstParent"

if (-not (Test-Path $srcRoot)) {
    Write-Host "No existe la carpeta en C: — nada que mover ni borrar."
    exit 0
}

$sizeMb = [math]::Round((Get-ChildItem $srcRoot -Recurse -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum / 1MB, 1)
Write-Host "Tamaño aproximado: $sizeMb MB"

New-Item -ItemType Directory -Force -Path $dstParent | Out-Null

if ($EliminarSinCopia) {
    Remove-Item -Path $srcRoot -Recurse -Force
    Write-Host "Eliminado: $srcRoot"
} else {
    if (Test-Path $dstDeepface) {
        $wSrc = Join-Path $srcRoot "weights"
        $wDst = Join-Path $dstDeepface "weights"
        if ((Test-Path $wSrc) -and -not (Test-Path $wDst)) {
            New-Item -ItemType Directory -Force -Path $wDst | Out-Null
            Copy-Item -Path (Join-Path $wSrc "*") -Destination $wDst -Recurse -Force -ErrorAction SilentlyContinue
        }
        Remove-Item -Path $srcRoot -Recurse -Force
        Write-Host "Contenido fusionado o sustituido; eliminado origen en C:."
    } else {
        Move-Item -Path $srcRoot -Destination $dstDeepface -Force
        Write-Host "Movido: $srcRoot -> $dstDeepface"
    }
}

# DeepFace espera DEEPFACE_HOME = carpeta que CONTIENE .deepface (no la carpeta .deepface en sí).
[System.Environment]::SetEnvironmentVariable("DEEPFACE_HOME", $dstParent, "User")
Write-Host "Variable de usuario DEEPFACE_HOME = $dstParent"
Write-Host "Listo. Cierre y vuelva a abrir la terminal para que surta efecto el entorno."
