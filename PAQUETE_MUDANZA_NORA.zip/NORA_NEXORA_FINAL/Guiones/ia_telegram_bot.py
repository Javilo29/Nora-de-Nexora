# -*- coding: utf-8 -*-
# Proyecto: Nora de Nexora - MyJNexoraVisual
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
import json
import os
import asyncio
import logging
import traceback
import urllib.request
from pathlib import Path

from dotenv import find_dotenv, load_dotenv

# Carga de llaves antes de Telegram: raíz del repo + find_dotenv (cwd)
_BOT_ROOT = Path(__file__).resolve().parent.parent
_ENV = _BOT_ROOT / ".env"
load_dotenv(dotenv_path=str(_ENV), override=True)
_fd = find_dotenv()
if _fd and Path(_fd).resolve() != _ENV.resolve():
    load_dotenv(dotenv_path=_fd, override=False)

from telegram import Update
from telegram.ext import ApplicationBuilder, ContextTypes, CommandHandler, MessageHandler, filters

from ia_paths import INBOX_DIR, LOGS_DIR
import ia_local_store

# Logs en archivo para depuración
LOGS_DIR.mkdir(parents=True, exist_ok=True)
ERROR_LOG = LOGS_DIR / "telegram_error.log"

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    handlers=[logging.FileHandler(str(ERROR_LOG)), logging.StreamHandler()]
)
logger = logging.getLogger("NoraLink")

# Bot esperado (v5.6). Si TELEGRAM_TOKEN apunta a otro @username, revise en BotFather y actualice .env
EXPECTED_TELEGRAM_BOT_USERNAME = "NoraNexoraBot"

# Constantes de Seguridad
TOKEN = os.environ.get("TELEGRAM_TOKEN")
ADMIN_ID = os.environ.get("TELEGRAM_ADMIN_ID", "").strip().replace("'", "").replace('"', "")


def _verify_telegram_bot_username() -> None:
    """Confirma vía getMe que el token corresponde al bot oficial, sin registrar el token en logs."""
    if not TOKEN:
        return
    try:
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{TOKEN}/getMe",
            headers={"User-Agent": "NoraTelegram/5.6"},
        )
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read().decode())
        un = (data.get("result") or {}).get("username") or ""
        if not un:
            logger.warning("getMe no devolvió username; revise el token en .env")
            return
        if un.lower() != EXPECTED_TELEGRAM_BOT_USERNAME.lower():
            logger.error(
                "El TELEGRAM_TOKEN activo es @%s; se esperaba @%s. "
                "Si sigue apareciendo 'Nora A' u otro bot, revoque el token antiguo en BotFather y pegue aquí el de @%s.",
                un,
                EXPECTED_TELEGRAM_BOT_USERNAME,
                EXPECTED_TELEGRAM_BOT_USERNAME,
            )
        else:
            logger.info("Token verificado: bot @%s (v5.6).", un)
    except Exception as e:
        logger.warning("No se pudo verificar getMe (red o token inválido): %s", e)

async def security_check(update: Update):
    if not update.effective_user: return False
    incoming_id = str(update.effective_user.id)
    if incoming_id != ADMIN_ID:
        logger.warning(f"🚫 Acceso no autorizado de ID: {incoming_id}")
        return False
    return True

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await security_check(update): return
    saludo = (
        "🧠 [Nora de Nexora v5.6]: Hola Javier, soy Nora — Arquitecto de Identidad y Especialista en "
        "Relaciones Humanas; Directora de Operaciones Diversificadas. ¿En qué materializamos su visión hoy?"
    )
    await update.message.reply_text(saludo)

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await security_check(update): return
    # CARGA DIFERIDA PARA AHORRAR RAM
    import ia_brain 
    
    await update.message.reply_text("🧠 [Nora de Nexora v5.6]: Recibido. Estoy revisando la imagen con detalle... 👁️")
    photo = update.message.photo[-1]
    new_file = await photo.get_file()
    file_name = f"telegram_{photo.file_unique_id}.jpg"
    file_path = INBOX_DIR / file_name
    await new_file.download_to_drive(str(file_path))
    
    analysis = ia_brain.analyze_document_with_vision(str(file_path))
    await update.message.reply_text(
        f"🧠 [Nora de Nexora v5.6]: ✅ Listo, Javier. Detectado como: {analysis.get('tipo_factura')}. "
        f"Estado: {analysis.get('estado_verificacion')}."
    )

async def handle_chat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await security_check(update): return
    eu = update.effective_user
    print(f"🧠 [Nora Link]: MENSAJE RECIBIDO DE {eu.first_name} (@{eu.username}): {update.message.text}")
    # CARGA DIFERIDA PARA AHORRAR RAM
    import ia_brain
    import ia_responder

    user_text = update.message.text
    uid = str(eu.id)
    affinity = ia_local_store.record_telegram_interaction(
        uid,
        display_name=eu.first_name,
        username=eu.username,
        topic_snippet=user_text,
    )
    is_creator = bool(ADMIN_ID) and uid == ADMIN_ID
    affinity_context = ia_responder.build_telegram_nora_context(
        is_creator=is_creator,
        display_name=eu.first_name,
        affinity=affinity,
    )
    logger.info(
        "Telegram afinidad user=%s trust=%s phase=%s n=%s",
        uid,
        affinity.get("trust_level"),
        affinity.get("phase"),
        affinity.get("interaction_count"),
    )
    try:
        if ia_brain.groq_client or ia_brain.gemini_model:
            persona = ia_responder.get_persona()
            prompt = (
                f"Responde a Javier: {user_text}"
                if is_creator
                else f"Mensaje del contacto: {user_text}"
            )
            response = ia_brain.chat_with_nora(
                prompt,
                persona_context=persona,
                affinity_context=affinity_context,
            )
            await update.message.reply_text(response)
        else:
            raise Exception("Ningún motor de IA inicializado (Groq ni Gemini)")
    except Exception as e:
        logger.error(f"Error en handle_chat [{type(e).__name__}]: {e}")
        traceback.print_exc()
        error_msg = f"🧠 [Nora de Nexora v5.6]: ¡Ups! Javier, error [{type(e).__name__}]. Reintente en 60 segundos."
        await update.message.reply_text(error_msg)
    finally:
        # Optimización de RAM: Limpieza tras respuesta
        import gc
        gc.collect()

async def post_init(application):
    if ADMIN_ID:
        try:
            msg = (
                "🧠 [Nora de Nexora v5.6]: Javier, sistema v5.6 multirrubro activo — Conciencia de Origen y "
                "Escalada de Afinidad. Lista para materializar su visión. Nexora bajo control."
            )
            await application.bot.send_message(chat_id=ADMIN_ID, text=msg)
            logger.info("Bot notificado al administrador.")
        except Exception as e:
            logger.error(f"Error post-init: {e}")

def run_bot():
    if not TOKEN:
        logger.error("No hay Token en .env.")
        return
    _verify_telegram_bot_username()
    print("Limpieza de identidad completada. Nora v5.6 Online", flush=True)

    app = ApplicationBuilder().token(TOKEN).post_init(post_init).build()
    app.add_handler(CommandHandler('start', start))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), handle_chat))
    
    print(f"🚀 Nora Link escuchando (Modo Ahorro RAM)... ID Admin: {ADMIN_ID}")
    app.run_polling()

if __name__ == '__main__':
    run_bot()
