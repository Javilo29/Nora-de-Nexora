# -*- coding: utf-8 -*-
"""
Nexora / Nora — arranque rápido (local o Replit).

Uso:
  python main.py              → bot de Telegram (predeterminado; mudanza Replit)
  python main.py dashboard    → panel Streamlit
  python main.py bot          → bot de Telegram

Replit: defina secretos (Secrets) y Run con `python main.py`. Opcional: NEXORA_MODE=dashboard para Streamlit.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
GUIONES = ROOT / "Guiones"
DASHBOARD = GUIONES / "ia_dashboard.py"
BOT = GUIONES / "ia_telegram_bot.py"


def _run_dashboard() -> int:
    port = os.environ.get("PORT", "8501")
    cmd = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        str(DASHBOARD),
        "--server.address",
        "0.0.0.0",
        "--server.port",
        str(port),
        "--browser.gatherUsageStats",
        "false",
    ]
    return subprocess.call(cmd, cwd=str(ROOT))


def _run_bot() -> int:
    return subprocess.call([sys.executable, str(BOT)], cwd=str(GUIONES))


def main() -> int:
    mode = (
        sys.argv[1].lower()
        if len(sys.argv) > 1
        else os.environ.get("NEXORA_MODE", "bot").lower()
    )
    if mode in ("dashboard", "streamlit", "ui", "panel"):
        return _run_dashboard()
    if mode in ("bot", "telegram", "tg"):
        return _run_bot()
    print(
        "Nexora — modos: bot | dashboard\n"
        "  python main.py              → Telegram\n"
        "  python main.py dashboard    → Streamlit (puerto PORT o 8501)\n",
        file=sys.stderr,
    )
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
